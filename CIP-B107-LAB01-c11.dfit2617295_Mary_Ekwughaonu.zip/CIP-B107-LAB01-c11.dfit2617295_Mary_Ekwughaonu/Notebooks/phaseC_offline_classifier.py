#!/usr/bin/env python3
"""
Phase C – Reproducible offline IP-candidate classifier
TF-IDF + Logistic Regression  |  Rule-based baseline  |  Holdout evaluation
"""

import json
import re
import ipaddress
import random
import numpy as np
import pandas as pd
from pathlib import Path
from collections import Counter

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score
)
from sklearn.pipeline import Pipeline
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ------------------------------------------------------------------
# Paths and reproducibility
# ------------------------------------------------------------------
BASE = Path.home() / "ICDFA_Second_Semester/CIP-B107-LAB01-c11.dfit2617295_Mary_Ekwughaonu"
CODE = BASE / "Working/IP_Identifier_Fine_Tuning/code"
EXPORTS = BASE / "Exports"
EXPORTS.mkdir(exist_ok=True)
REPORT = BASE / "Report"
REPORT.mkdir(exist_ok=True)

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

print("=" * 60)
print("PHASE C – Offline Classifier + Rule Baseline")
print("=" * 60)

# ------------------------------------------------------------------
# 1. Load train / test JSONL (fixed holdout required by brief)
# ------------------------------------------------------------------
def load_jsonl(path):
    records = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            prompt = obj["prompt"]
            completion = obj["completion"].strip().lower()
            # Map to binary: positive = 1, everything else = 0
            label = 1 if "positive" in completion else 0
            records.append({"prompt": prompt, "label": label, "completion": completion})
    return pd.DataFrame(records)

train_df = load_jsonl(CODE / "dataset_train.jsonl")
test_df  = load_jsonl(CODE / "dataset_test.jsonl")

print(f"\nTrain records : {len(train_df)}  (expected 183)")
print(f"Test records  : {len(test_df)}   (expected 46)")
print(f"Train label balance : {dict(Counter(train_df['label']))}")
print(f"Test  label balance : {dict(Counter(test_df['label']))}")

# ------------------------------------------------------------------
# 2. Simple leakage check (near-identical prompts across split)
# ------------------------------------------------------------------
train_prompts = set(train_df["prompt"].str.strip())
test_prompts  = set(test_df["prompt"].str.strip())
overlap = train_prompts & test_prompts
print(f"\nExact prompt overlap between train and test : {len(overlap)}")
if len(overlap) > 0:
    print("  WARNING: exact duplicates cross the split – leakage risk exists")
else:
    print("  No exact prompt overlap detected")

# ------------------------------------------------------------------
# 3. Rule-based baseline (regex + strict IPv4)
# ------------------------------------------------------------------
IP_RE = re.compile(r'(?<![\d.])(\d{1,3}(?:\.\d{1,3}){3})(?![\d.])')

def extract_candidate(prompt: str) -> str:
    """Pull the candidate that appears after the semicolon (dataset convention)."""
    if ";" in prompt:
        part = prompt.split(";")[-1]
        # remove trailing "->" and whitespace
        part = part.replace("->", "").strip()
        return part
    m = IP_RE.search(prompt)
    return m.group(1) if m else ""

def rule_baseline_predict(prompt: str) -> int:
    """
    Positive only when the candidate is a strict valid IPv4 address.
    This is a transparent, deterministic baseline.
    """
    cand = extract_candidate(prompt)
    if not cand:
        return 0
    try:
        ipaddress.IPv4Address(cand)
        return 1
    except (ipaddress.AddressValueError, ValueError):
        return 0

test_df["rule_pred"] = test_df["prompt"].apply(rule_baseline_predict)
print("\n--- Rule-based baseline on holdout ---")
print(classification_report(test_df["label"], test_df["rule_pred"],
                            target_names=["negative", "positive"], digits=4))
print("Confusion matrix (rows=true, cols=pred):")
print(confusion_matrix(test_df["label"], test_df["rule_pred"]))

# ------------------------------------------------------------------
# 4. TF-IDF + Logistic Regression (fit ONLY on training data)
# ------------------------------------------------------------------
pipe = Pipeline([
    ("tfidf", TfidfVectorizer(
        analyzer="char_wb",          # character n-grams work well for short IP-like strings
        ngram_range=(2, 5),
        min_df=1,
        max_features=5000
    )),
    ("clf", LogisticRegression(
        random_state=RANDOM_SEED,
        max_iter=1000,
        class_weight="balanced"      # help with any imbalance
    ))
])

print("\nFitting TF-IDF + Logistic Regression on training set only ...")
pipe.fit(train_df["prompt"], train_df["label"])

# Predict on holdout
test_df["ml_pred"] = pipe.predict(test_df["prompt"])
test_df["ml_prob"] = pipe.predict_proba(test_df["prompt"])[:, 1]

print("\n--- TF-IDF + Logistic Regression on holdout ---")
print(classification_report(test_df["label"], test_df["ml_pred"],
                            target_names=["negative", "positive"], digits=4))
cm = confusion_matrix(test_df["label"], test_df["ml_pred"])
print("Confusion matrix (rows=true, cols=pred):")
print(cm)

# Metrics
acc  = accuracy_score(test_df["label"], test_df["ml_pred"])
prec = precision_score(test_df["label"], test_df["ml_pred"], zero_division=0)
rec  = recall_score(test_df["label"], test_df["ml_pred"], zero_division=0)
f1   = f1_score(test_df["label"], test_df["ml_pred"], zero_division=0)

print(f"\nAccuracy  : {acc:.4f}")
print(f"Precision : {prec:.4f}")
print(f"Recall    : {rec:.4f}")
print(f"F1        : {f1:.4f}")

# AUROC / AUPRC if both classes present
if len(set(test_df["label"])) == 2:
    try:
        auroc = roc_auc_score(test_df["label"], test_df["ml_prob"])
        auprc = average_precision_score(test_df["label"], test_df["ml_prob"])
        print(f"AUROC     : {auroc:.4f}")
        print(f"AUPRC     : {auprc:.4f}")
    except Exception as e:
        print("AUROC/AUPRC not computed:", e)
        auroc = auprc = None
else:
    auroc = auprc = None

# Majority-class baseline
majority = test_df["label"].mode()[0]
maj_pred = [majority] * len(test_df)
maj_acc = accuracy_score(test_df["label"], maj_pred)
print(f"\nMajority-class baseline accuracy : {maj_acc:.4f}  (always predict {majority})")

# ------------------------------------------------------------------
# 5. Save predictions, model, metrics, confusion-matrix plot
# ------------------------------------------------------------------
pred_out = test_df[["prompt", "label", "rule_pred", "ml_pred", "ml_prob"]].copy()
pred_out.columns = ["prompt", "actual", "rule_predicted", "ml_predicted", "ml_probability"]
pred_path = EXPORTS / "predictions.csv"
pred_out.to_csv(pred_path, index=False)
print(f"\nPredictions saved → {pred_path}")

# Save the fitted pipeline
model_path = EXPORTS / "tfidf_logreg_pipeline.joblib"
joblib.dump(pipe, model_path)
print(f"Model saved      → {model_path}")

# Confusion matrix figure
fig, ax = plt.subplots(figsize=(5, 4))
im = ax.imshow(cm, interpolation="nearest", cmap=plt.cm.Blues)
ax.figure.colorbar(im, ax=ax)
ax.set(xticks=[0, 1], yticks=[0, 1],
       xticklabels=["Pred Neg", "Pred Pos"],
       yticklabels=["True Neg", "True Pos"],
       ylabel="True label", xlabel="Predicted label",
       title="Confusion Matrix – TF-IDF + LogReg (holdout)")
for i in range(2):
    for j in range(2):
        ax.text(j, i, format(cm[i, j], "d"),
                ha="center", va="center",
                color="white" if cm[i, j] > cm.max() / 2 else "black")
fig.tight_layout()
cm_path = EXPORTS / "confusion_matrix_phaseC.png"
fig.savefig(cm_path, dpi=150)
plt.close()
print(f"Confusion matrix plot → {cm_path}")

# Metrics summary file
with open(EXPORTS / "phaseC_metrics.txt", "w") as f:
    f.write("Phase C – Offline Classifier Metrics\n")
    f.write(f"Random seed          : {RANDOM_SEED}\n")
    f.write(f"Train size           : {len(train_df)}\n")
    f.write(f"Test size            : {len(test_df)}\n")
    f.write(f"Exact prompt overlap : {len(overlap)}\n\n")
    f.write("--- Rule-based baseline ---\n")
    f.write(classification_report(test_df["label"], test_df["rule_pred"],
                                  target_names=["negative", "positive"], digits=4))
    f.write("\n--- TF-IDF + Logistic Regression ---\n")
    f.write(classification_report(test_df["label"], test_df["ml_pred"],
                                  target_names=["negative", "positive"], digits=4))
    f.write(f"\nAccuracy  : {acc:.4f}\n")
    f.write(f"Precision : {prec:.4f}\n")
    f.write(f"Recall    : {rec:.4f}\n")
    f.write(f"F1        : {f1:.4f}\n")
    if auroc is not None:
        f.write(f"AUROC     : {auroc:.4f}\n")
        f.write(f"AUPRC     : {auprc:.4f}\n")
    f.write(f"\nMajority-class baseline accuracy : {maj_acc:.4f}\n")
print(f"Metrics text       → {EXPORTS / 'phaseC_metrics.txt'}")

# Package versions
import sklearn, pandas as pd, sys
print("\n--- Environment ---")
print(f"Python      : {sys.version.split()[0]}")
print(f"scikit-learn: {sklearn.__version__}")
print(f"pandas      : {pd.__version__}")
print(f"numpy       : {np.__version__}")

print("\n" + "=" * 60)
print("Phase C complete.")
print("=" * 60)
