#!/usr/bin/env python3
"""
Phase B – IP candidate extraction, strict IPv4 validation, and review table.
"""

import re
import csv
import ipaddress
import pandas as pd
from pathlib import Path

BASE = Path.home() / "ICDFA_Second_Semester/CIP-B107-LAB01-c11.dfit2617295_Mary_Ekwughaonu"
CSV_PATH = BASE / "Working/IP_Identifier_Fine_Tuning/code/dataset_small.csv"
OUT_PATH = BASE / "Exports/candidate_review.csv"

# Regex that finds dotted-decimal candidates (4 groups of digits)
# This is deliberately permissive so we can later show false positives
IP_CANDIDATE_RE = re.compile(
    r'(?<![\d.])'          # not preceded by digit or dot
    r'(\d{1,3}(?:\.\d{1,3}){3})'
    r'(?![\d.])'           # not followed by digit or dot
)

def is_strict_ipv4(text: str) -> bool:
    """Return True only if the string is a syntactically valid IPv4 address."""
    try:
        ipaddress.IPv4Address(text)
        return True
    except (ipaddress.AddressValueError, ValueError):
        return False

def main():
    df = pd.read_csv(CSV_PATH)
    print(f"Loaded {len(df)} rows from {CSV_PATH.name}")

    rows = []
    demo_samples = []   # keep a few interesting examples for the report

    for idx, row in df.iterrows():
        context = str(row.get("text", ""))
        source_ip_col = str(row.get("ip", ""))
        source_label = str(row.get("class", ""))

        # Search both the dedicated ip column and the surrounding text
        search_space = f"{source_ip_col} {context}"
        matches = IP_CANDIDATE_RE.findall(search_space)

        # Also treat the ip column itself as a candidate even if regex misses it
        candidates = set(matches)
        if source_ip_col and source_ip_col not in candidates:
            candidates.add(source_ip_col)

        if not candidates:
            # still record a row so we have full coverage
            rows.append({
                "source_row": idx,
                "context": context[:120],
                "candidate": "",
                "regex_match": False,
                "ipv4_valid": False,
                "source_label": source_label,
                "source_ip_column": source_ip_col,
                "analyst_note": "No dotted-decimal candidate found"
            })
            continue

        for cand in candidates:
            regex_hit = bool(IP_CANDIDATE_RE.search(cand)) or cand in matches
            valid = is_strict_ipv4(cand)

            note = ""
            if regex_hit and not valid:
                note = "Regex match but NOT strict IPv4 (e.g. invalid octet / leading zeros / out-of-range)"
            elif valid and source_label in ("N", "negative"):
                note = "Strict valid IPv4 but source labelled negative / non-IP"
            elif not valid and source_label in ("A", "positive"):
                note = "Source labelled positive but fails strict IPv4 validation"
            elif valid and source_label in ("A", "positive"):
                note = "Regex + strict IPv4 + source positive – consistent"
            else:
                note = "Review manually"

            rec = {
                "source_row": idx,
                "context": context[:120],
                "candidate": cand,
                "regex_match": regex_hit,
                "ipv4_valid": valid,
                "source_label": source_label,
                "source_ip_column": source_ip_col,
                "analyst_note": note
            }
            rows.append(rec)

            # Collect interesting demos
            if len(demo_samples) < 15:
                if (not valid and regex_hit) or ("000" in cand) or (source_label == "N") or ("608" in cand):
                    demo_samples.append(rec)

    # Write the full review table
    out_df = pd.DataFrame(rows)
    out_df.to_csv(OUT_PATH, index=False)
    print(f"\nWrote {len(out_df)} candidate rows → {OUT_PATH}")

    # Summary counts
    print("\n=== SUMMARY ===")
    print(f"Total candidate rows exported : {len(out_df)}")
    print(f"Regex matches                 : {out_df['regex_match'].sum()}")
    print(f"Strict IPv4 valid             : {out_df['ipv4_valid'].sum()}")
    print(f"Source label distribution     :\n{out_df['source_label'].value_counts()}")

    print("\n=== 10+ DEMO SAMPLES (for report) ===")
    for i, s in enumerate(demo_samples[:12], 1):
        print(f"\n--- Sample {i} ---")
        print(f"  Row        : {s['source_row']}")
        print(f"  Candidate  : {s['candidate']}")
        print(f"  Regex hit  : {s['regex_match']}")
        print(f"  IPv4 valid : {s['ipv4_valid']}")
        print(f"  Source lbl : {s['source_label']}")
        print(f"  Context    : {s['context'][:80]}")
        print(f"  Note       : {s['analyst_note']}")

if __name__ == "__main__":
    main()
