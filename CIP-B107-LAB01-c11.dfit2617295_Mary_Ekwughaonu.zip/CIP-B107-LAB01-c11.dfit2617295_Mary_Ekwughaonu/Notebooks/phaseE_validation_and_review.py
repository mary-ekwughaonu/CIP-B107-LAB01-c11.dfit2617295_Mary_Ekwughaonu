#!/usr/bin/env python3
"""
Phase E – Actual-vs-predicted table, metrics, analyst review (8+ records),
and high-accuracy counter-example.
"""

import json
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.metrics import (
    confusion_matrix, accuracy_score, precision_score,
    recall_score, f1_score, classification_report,
    roc_auc_score, average_precision_score
)

BASE = Path.home() / "ICDFA_Second_Semester/CIP-B107-LAB01-c11.dfit2617295_Mary_Ekwughaonu"
CODE = BASE / "Working/IP_Identifier_Fine_Tuning/code"
EXPORTS = BASE / "Exports"
EXPORTS.mkdir(exist_ok=True)

print("=" * 60)
print("PHASE E – Validation, Investigation & Interpretation")
print("=" * 60)

# ------------------------------------------------------------------
# 1. Load predictions produced in Phase C
# ------------------------------------------------------------------
pred = pd.read_csv(EXPORTS / "predictions.csv")
print(f"\nLoaded predictions.csv  →  {len(pred)} holdout records")
print(pred.columns.tolist())

# Ensure integer labels
pred["actual"] = pred["actual"].astype(int)
pred["ml_predicted"] = pred["ml_predicted"].astype(int)
pred["rule_predicted"] = pred["rule_predicted"].astype(int)

# ------------------------------------------------------------------
# 2. Confusion matrix terms (positive class = 1)
# ------------------------------------------------------------------
def label_outcome(row):
    a, p = row["actual"], row["ml_predicted"]
    if a == 1 and p == 1: return "TP"
    if a == 0 and p == 0: return "TN"
    if a == 0 and p == 1: return "FP"
    if a == 1 and p == 0: return "FN"
    return "?"

pred["outcome"] = pred.apply(label_outcome, axis=1)
print("\n=== OUTCOME COUNTS (ML model) ===")
print(pred["outcome"].value_counts())

cm = confusion_matrix(pred["actual"], pred["ml_predicted"])
print("\nConfusion matrix (rows=actual, cols=predicted):")
print("        Pred_Neg  Pred_Pos")
print(f"Act_Neg  {cm[0,0]:7d}  {cm[0,1]:7d}")
print(f"Act_Pos  {cm[1,0]:7d}  {cm[1,1]:7d}")

# ------------------------------------------------------------------
# 3. Metrics from student's own predictions
# ------------------------------------------------------------------
acc  = accuracy_score(pred["actual"], pred["ml_predicted"])
prec = precision_score(pred["actual"], pred["ml_predicted"], zero_division=0)
rec  = recall_score(pred["actual"], pred["ml_predicted"], zero_division=0)
f1   = f1_score(pred["actual"], pred["ml_predicted"], zero_division=0)

print("\n=== ML MODEL METRICS (from predictions.csv) ===")
print(f"Accuracy  : {acc:.4f}")
print(f"Precision : {prec:.4f}")
print(f"Recall    : {rec:.4f}")
print(f"F1        : {f1:.4f}")

if "ml_probability" in pred.columns and pred["actual"].nunique() == 2:
    try:
        auroc = roc_auc_score(pred["actual"], pred["ml_probability"])
        auprc = average_precision_score(pred["actual"], pred["ml_probability"])
        print(f"AUROC     : {auroc:.4f}")
        print(f"AUPRC     : {auprc:.4f}")
    except Exception as e:
        print("AUROC/AUPRC:", e)
        auroc = auprc = None
else:
    auroc = auprc = None

# Majority-class baseline
majority = pred["actual"].mode()[0]
maj_acc = accuracy_score(pred["actual"], [majority] * len(pred))
print(f"\nMajority-class baseline accuracy : {maj_acc:.4f}  (always predict {majority})")

print("\nFull classification report:")
print(classification_report(pred["actual"], pred["ml_predicted"],
                            target_names=["negative", "positive"], digits=4))

# ------------------------------------------------------------------
# 4. Full actual-vs-predicted table (saved)
# ------------------------------------------------------------------
table_path = EXPORTS / "actual_vs_predicted_table.csv"
pred.to_csv(table_path, index=False)
print(f"\nFull table saved → {table_path}")

# ------------------------------------------------------------------
# 5. Analyst review – at least 8 records
#    Prefer: errors first, then borderline, then clear TP/TN
# ------------------------------------------------------------------
print("\n" + "=" * 60)
print("ANALYST REVIEW (minimum 8 records)")
print("=" * 60)

review_rows = []

# Prefer errors
errors = pred[pred["outcome"].isin(["FP", "FN"])]
for _, r in errors.iterrows():
    review_rows.append(r)
    if len(review_rows) >= 4:
        break

# Add some clear negatives (TN) and positives (TP)
tns = pred[pred["outcome"] == "TN"]
tps = pred[pred["outcome"] == "TP"]

for _, r in tns.head(2).iterrows():
    review_rows.append(r)
for _, r in tps.head(2).iterrows():
    review_rows.append(r)

# If still short, add borderline by probability
if len(review_rows) < 8 and "ml_probability" in pred.columns:
    borderline = pred[(pred["ml_probability"] > 0.35) & (pred["ml_probability"] < 0.65)]
    for _, r in borderline.head(8 - len(review_rows)).iterrows():
        review_rows.append(r)

# Pad with any remaining if needed
if len(review_rows) < 8:
    for _, r in pred.head(8).iterrows():
        if len(review_rows) >= 8:
            break
        review_rows.append(r)

# Deduplicate while preserving order
seen = set()
unique_review = []
for r in review_rows:
    key = (r["prompt"], r["actual"], r["ml_predicted"])
    if key not in seen:
        seen.add(key)
        unique_review.append(r)
    if len(unique_review) >= 8:
        break

print(f"\nSelected {len(unique_review)} records for analyst review:\n")

review_records = []
for i, r in enumerate(unique_review, 1):
    prompt_short = str(r["prompt"])[:90].replace("\n", " ")
    note = ""
    if r["outcome"] == "TP":
        note = "True Positive – model correctly flagged IP-candidate evidence."
    elif r["outcome"] == "TN":
        note = "True Negative – model correctly rejected non-IP / malformed string."
    elif r["outcome"] == "FP":
        note = "False Positive – model flagged as IP evidence but source label is negative. Analyst should inspect context before acting."
    elif r["outcome"] == "FN":
        note = "False Negative – real IP evidence missed. High forensic risk; escalate for manual review."
    else:
        note = "Borderline / review manually."

    print(f"--- Review #{i}  [{r['outcome']}] ---")
    print(f"  Prompt (truncated): {prompt_short}")
    print(f"  Actual label    : {r['actual']}   ML pred: {r['ml_predicted']}   Rule pred: {r['rule_predicted']}")
    if "ml_probability" in r:
        print(f"  ML probability  : {r['ml_probability']:.4f}")
    print(f"  Analyst note    : {note}")
    print()

    review_records.append({
        "review_id": i,
        "outcome": r["outcome"],
        "prompt": r["prompt"],
        "actual": int(r["actual"]),
        "ml_predicted": int(r["ml_predicted"]),
        "rule_predicted": int(r["rule_predicted"]),
        "ml_probability": float(r["ml_probability"]) if "ml_probability" in r else None,
        "analyst_note": note
    })

review_df = pd.DataFrame(review_records)
review_path = EXPORTS / "analyst_review_8records.csv"
review_df.to_csv(review_path, index=False)
print(f"Analyst review table → {review_path}")

# ------------------------------------------------------------------
# 6. Counter-example: high accuracy can still be operationally weak
# ------------------------------------------------------------------
print("\n" + "=" * 60)
print("COUNTER-EXAMPLE – High accuracy on imbalanced data")
print("=" * 60)

n = len(pred)
n_pos = int((pred["actual"] == 1).sum())
n_neg = n - n_pos
print(f"Holdout size     : {n}")
print(f"Actual positives : {n_pos}")
print(f"Actual negatives : {n_neg}")
print(f"ML accuracy      : {acc:.4f}")
print(f"Majority baseline: {maj_acc:.4f}")

print("""
Illustration:
  Suppose a triage system achieves 97–98 % accuracy on a set that is already
  majority-positive (or majority-negative). The headline accuracy looks strong,
  yet the few errors that remain can be the most operationally important ones.

  In forensic IP triage the critical error is usually a FALSE NEGATIVE:
  a genuine IP address that the classifier marks “not evidence”. That address
  never reaches an analyst, so follow-up investigation never starts.

  Conversely, a false positive costs analyst time but does not hide evidence.
  Therefore high accuracy alone is insufficient. Precision, recall (especially
  recall on the positive class), and a mandatory analyst-review step for
  borderline or negative predictions are required before any operational use.

  Recommendation: deploy only as analyst assistance, never as an autonomous
  filter that discards records without human review.
""")

# ------------------------------------------------------------------
# 7. Save Phase E summary
# ------------------------------------------------------------------
with open(EXPORTS / "phaseE_summary.txt", "w") as f:
    f.write("Phase E – Validation Summary\n")
    f.write(f"Holdout records        : {len(pred)}\n")
    f.write(f"Outcome counts         : {dict(pred['outcome'].value_counts())}\n")
    f.write(f"Accuracy               : {acc:.4f}\n")
    f.write(f"Precision              : {prec:.4f}\n")
    f.write(f"Recall                 : {rec:.4f}\n")
    f.write(f"F1                     : {f1:.4f}\n")
    if auroc is not None:
        f.write(f"AUROC                  : {auroc:.4f}\n")
        f.write(f"AUPRC                  : {auprc:.4f}\n")
    f.write(f"Majority baseline acc  : {maj_acc:.4f}\n")
    f.write(f"Analyst review records : {len(unique_review)}\n")
    f.write("Files: actual_vs_predicted_table.csv, analyst_review_8records.csv\n")

print(f"\nSummary → {EXPORTS / 'phaseE_summary.txt'}")
print("\n" + "=" * 60)
print("Phase E complete.")
print("=" * 60)
