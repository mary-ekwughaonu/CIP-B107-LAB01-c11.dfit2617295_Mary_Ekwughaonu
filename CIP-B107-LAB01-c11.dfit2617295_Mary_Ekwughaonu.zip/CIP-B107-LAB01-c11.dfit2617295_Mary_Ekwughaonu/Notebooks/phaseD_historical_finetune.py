#!/usr/bin/env python3
"""
Phase D – Investigate historical fine-tuning evidence
(result.csv + fine_tuning_steps.txt). No new API calls.
"""

import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = Path.home() / "ICDFA_Second_Semester/CIP-B107-LAB01-c11.dfit2617295_Mary_Ekwughaonu"
CODE = BASE / "Working/IP_Identifier_Fine_Tuning/code"
EXPORTS = BASE / "Exports"
EXPORTS.mkdir(exist_ok=True)

print("=" * 60)
print("PHASE D – Historical Fine-Tuning Evidence")
print("=" * 60)

# ------------------------------------------------------------------
# 1. Load the two historical files
# ------------------------------------------------------------------
steps = pd.read_csv(CODE / "fine_tuning_steps.txt")
result = pd.read_csv(CODE / "result.csv")

print("\n--- fine_tuning_steps.txt ---")
print(f"Rows : {len(steps)}")
print(f"Columns : {list(steps.columns)}")
print(steps.head(3).to_string())
print("...")
print(steps.tail(3).to_string())

print("\n--- result.csv ---")
print(f"Rows : {len(result)}")
print(f"Columns : {list(result.columns)}")
print(result.head(3).to_string())

# ------------------------------------------------------------------
# 2. Distinguish training metrics from classification metrics
# ------------------------------------------------------------------
print("\n=== METRIC AVAILABILITY ===")
for col in result.columns:
    non_null = result[col].notna().sum()
    print(f"  {col:40s}  non-null values: {non_null}/{len(result)}")

# ------------------------------------------------------------------
# 3. Final non-null recorded classification metrics
# ------------------------------------------------------------------
metric_cols = [
    "classification/accuracy",
    "classification/precision",
    "classification/recall",
    "classification/f1.0",
    "classification/auroc",
    "classification/auprc",
]

print("\n=== FINAL NON-NULL CLASSIFICATION METRICS (from result.csv) ===")
final_metrics = {}
for col in metric_cols:
    if col not in result.columns:
        print(f"  {col}: COLUMN NOT PRESENT")
        continue
    series = result[col].dropna()
    if len(series) == 0:
        print(f"  {col}: no non-null values recorded")
        final_metrics[col] = None
    else:
        # take the last non-null value (end of training log)
        val = series.iloc[-1]
        step = result.loc[series.index[-1], "step"] if "step" in result.columns else "?"
        print(f"  {col:40s} = {val:.6f}   (last recorded at step {step})")
        final_metrics[col] = val

# Also show training loss at the end
if "training_loss" in result.columns:
    last_loss = result["training_loss"].dropna().iloc[-1]
    print(f"\n  Last training_loss                 = {last_loss:.6f}")

if "training_sequence_accuracy" in result.columns:
    last_seq = result["training_sequence_accuracy"].dropna().iloc[-1]
    print(f"  Last training_sequence_accuracy    = {last_seq:.6f}")

# ------------------------------------------------------------------
# 4. Plots
# ------------------------------------------------------------------
fig, axes = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# Plot 1 – training loss
ax = axes[0]
if "training_loss" in result.columns:
    ax.plot(result["step"], result["training_loss"], label="training_loss", color="C0")
if "validation_loss" in result.columns and result["validation_loss"].notna().any():
    ax.plot(result["step"], result["validation_loss"], label="validation_loss", color="C1", alpha=0.7)
ax.set_ylabel("Loss")
ax.set_title("Historical Fine-Tuning – Loss vs Step")
ax.legend()
ax.grid(True, alpha=0.3)

# Plot 2 – classification metrics (where present)
ax = axes[1]
plotted = False
for col, color in [
    ("classification/accuracy", "C2"),
    ("classification/precision", "C3"),
    ("classification/recall", "C4"),
    ("classification/f1.0", "C5"),
    ("classification/auroc", "C6"),
]:
    if col in result.columns and result[col].notna().any():
        ax.plot(result["step"], result[col], label=col.replace("classification/", ""), color=color)
        plotted = True
if plotted:
    ax.set_ylabel("Metric value")
    ax.set_title("Historical Fine-Tuning – Classification Metrics vs Step")
    ax.legend()
    ax.grid(True, alpha=0.3)
else:
    ax.text(0.5, 0.5, "No classification metrics recorded in result.csv",
            ha="center", va="center", transform=ax.transAxes)
    ax.set_title("Classification Metrics (none available)")

axes[-1].set_xlabel("Training step")
fig.tight_layout()
plot_path = EXPORTS / "phaseD_historical_metrics.png"
fig.savefig(plot_path, dpi=150)
plt.close()
print(f"\nPlot saved → {plot_path}")

# ------------------------------------------------------------------
# 5. What can / cannot be concluded
# ------------------------------------------------------------------
print("\n=== INTERPRETATION NOTES ===")
print("""
CAN be concluded from the historical files:
  - Training loss generally decreased over steps (model fitted the training data).
  - Some classification metrics were logged at certain steps.
  - The final non-null values above are the last recorded snapshot in result.csv.

CANNOT be concluded / important limitations:
  - These metrics are from a historical fine-tuning run on a legacy model
    (commonly referenced as “ada” in older OpenAI fine-tuning workflows).
  - Training-sequence accuracy is NOT the same as independent holdout performance.
  - Many early steps have empty classification columns – metrics were not logged
    at every step.
  - The historic API endpoints and model names are obsolete; the scripts that
    upload data or create fine-tune jobs must NOT be executed.
  - No claim is made that the historical model is still reachable or that the
    recorded numbers equal a fresh student-run experiment.
""")

# ------------------------------------------------------------------
# 6. Save a short metrics extract for the report
# ------------------------------------------------------------------
with open(EXPORTS / "phaseD_historical_summary.txt", "w") as f:
    f.write("Phase D – Historical Fine-Tuning Summary\n")
    f.write(f"result.csv rows          : {len(result)}\n")
    f.write(f"fine_tuning_steps rows   : {len(steps)}\n\n")
    f.write("Final non-null classification metrics:\n")
    for k, v in final_metrics.items():
        f.write(f"  {k}: {v}\n")
    f.write("\nNote: These values come from the supplied historical log only.\n")
    f.write("They are not a new student fine-tuning run.\n")

print(f"Summary text → {EXPORTS / 'phaseD_historical_summary.txt'}")
print("\n" + "=" * 60)
print("Phase D complete.")
print("=" * 60)
